package com.example.calculator

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.math.BigDecimal
import java.math.MathContext

/** منطق ماشین‌حساب: چهار عمل اصلی، درصد، تغییر علامت و پاک‌کردن. */
class CalculatorState {

    var display by mutableStateOf("0")
        private set
    var expression by mutableStateOf("")
        private set

    private var accumulator: BigDecimal? = null
    private var pendingOp: Char? = null
    private var startNewNumber = true
    private var hasError = false

    fun digit(d: Char) {
        if (hasError) clear()
        when {
            startNewNumber -> {
                display = d.toString()
                startNewNumber = false
            }
            display == "0" -> display = d.toString()
            display.length < 15 -> display += d
        }
    }

    fun dot() {
        if (hasError) clear()
        if (startNewNumber) {
            display = "0."
            startNewNumber = false
        } else if (!display.contains('.')) {
            display += "."
        }
    }

    fun operator(newOp: Char) {
        if (hasError) return
        val op = pendingOp
        if (op != null && !startNewNumber) {
            val result = apply(accumulator!!, BigDecimal(display), op) ?: return fail()
            accumulator = result
            display = format(result)
        } else if (op == null) {
            accumulator = BigDecimal(display)
        }
        pendingOp = newOp
        startNewNumber = true
        expression = "${format(accumulator!!)} $newOp"
    }

    fun equals() {
        val op = pendingOp
        if (hasError || op == null) return
        val left = accumulator!!
        val right = BigDecimal(display)
        val result = apply(left, right, op) ?: return fail()
        expression = "${format(left)} $op ${format(right)} ="
        display = format(result)
        accumulator = null
        pendingOp = null
        startNewNumber = true
    }

    fun percent() {
        if (hasError) return
        display = format(BigDecimal(display).divide(BigDecimal(100)))
        startNewNumber = true
    }

    fun negate() {
        if (hasError || display == "0") return
        display = if (display.startsWith("-")) display.drop(1) else "-$display"
    }

    fun backspace() {
        if (hasError) return clear()
        if (startNewNumber) return
        display = if (display.length == 1 || (display.length == 2 && display.startsWith("-"))) {
            "0"
        } else {
            display.dropLast(1)
        }
    }

    fun clear() {
        display = "0"
        expression = ""
        accumulator = null
        pendingOp = null
        startNewNumber = true
        hasError = false
    }

    private fun fail() {
        clear()
        display = "خطا"
        hasError = true
    }

    private fun apply(a: BigDecimal, b: BigDecimal, op: Char): BigDecimal? = when (op) {
        '+' -> a.add(b)
        '−' -> a.subtract(b)
        '×' -> a.multiply(b, MC)
        '÷' -> if (b.signum() == 0) null else a.divide(b, MC)
        else -> null
    }

    private fun format(value: BigDecimal): String {
        val rounded = value.round(MC)
        val stripped = if (rounded.signum() == 0) BigDecimal.ZERO else rounded.stripTrailingZeros()
        val plain = stripped.toPlainString()
        return if (plain.length > 16) stripped.toString() else plain
    }

    private companion object {
        val MC = MathContext(12)
    }
}
