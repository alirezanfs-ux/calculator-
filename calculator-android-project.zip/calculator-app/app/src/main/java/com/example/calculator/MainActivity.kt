package com.example.calculator

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val dark = isSystemInDarkTheme()
            MaterialTheme(colorScheme = if (dark) darkColorScheme() else lightColorScheme()) {
                // اعداد و صفحه‌کلید ماشین‌حساب همیشه چپ‌به‌راست‌اند.
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                    CalculatorScreen()
                }
            }
        }
    }
}

@Composable
fun CalculatorScreen() {
    val calc = remember { CalculatorState() }
    val colors = MaterialTheme.colorScheme

    val numberBg = colors.surfaceVariant
    val numberFg = colors.onSurfaceVariant
    val funcBg = colors.secondaryContainer
    val funcFg = colors.onSecondaryContainer
    val opBg = colors.primary
    val opFg = colors.onPrimary

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(colors.background)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // صفحه نمایش
        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(horizontal = 8.dp),
            verticalArrangement = Arrangement.Bottom,
            horizontalAlignment = Alignment.End
        ) {
            Text(
                text = calc.expression,
                fontSize = 22.sp,
                color = colors.onBackground.copy(alpha = 0.6f),
                maxLines = 1,
                textAlign = TextAlign.End
            )
            Text(
                text = calc.display,
                fontSize = when {
                    calc.display.length > 12 -> 36.sp
                    calc.display.length > 8 -> 48.sp
                    else -> 64.sp
                },
                color = colors.onBackground,
                maxLines = 1,
                textAlign = TextAlign.End,
                modifier = Modifier.fillMaxWidth()
            )
        }

        ButtonRow {
            CalcButton("AC", funcBg, funcFg) { calc.clear() }
            CalcButton("⌫", funcBg, funcFg) { calc.backspace() }
            CalcButton("%", funcBg, funcFg) { calc.percent() }
            CalcButton("÷", opBg, opFg) { calc.operator('÷') }
        }
        ButtonRow {
            CalcButton("7", numberBg, numberFg) { calc.digit('7') }
            CalcButton("8", numberBg, numberFg) { calc.digit('8') }
            CalcButton("9", numberBg, numberFg) { calc.digit('9') }
            CalcButton("×", opBg, opFg) { calc.operator('×') }
        }
        ButtonRow {
            CalcButton("4", numberBg, numberFg) { calc.digit('4') }
            CalcButton("5", numberBg, numberFg) { calc.digit('5') }
            CalcButton("6", numberBg, numberFg) { calc.digit('6') }
            CalcButton("−", opBg, opFg) { calc.operator('−') }
        }
        ButtonRow {
            CalcButton("1", numberBg, numberFg) { calc.digit('1') }
            CalcButton("2", numberBg, numberFg) { calc.digit('2') }
            CalcButton("3", numberBg, numberFg) { calc.digit('3') }
            CalcButton("+", opBg, opFg) { calc.operator('+') }
        }
        ButtonRow {
            CalcButton("±", numberBg, numberFg) { calc.negate() }
            CalcButton("0", numberBg, numberFg) { calc.digit('0') }
            CalcButton(".", numberBg, numberFg) { calc.dot() }
            CalcButton("=", opBg, opFg) { calc.equals() }
        }
    }
}

@Composable
private fun ButtonRow(content: @Composable androidx.compose.foundation.layout.RowScope.() -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        content = content
    )
}

@Composable
private fun androidx.compose.foundation.layout.RowScope.CalcButton(
    label: String,
    container: Color,
    content: Color,
    onClick: () -> Unit
) {
    Button(
        onClick = onClick,
        modifier = Modifier
            .weight(1f)
            .aspectRatio(1f),
        shape = CircleShape,
        colors = ButtonDefaults.buttonColors(containerColor = container, contentColor = content),
        contentPadding = PaddingValues(0.dp)
    ) {
        Text(text = label, fontSize = 28.sp)
    }
}
